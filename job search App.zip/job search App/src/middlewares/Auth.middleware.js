import userModel from "../DB/models/userModel.js";
import {verify} from "../utils/token/token.js";
import asyncHandler from "../utils/asyncHandler.js";
import *as dbService from "../DB/DB.Service.js";
import { tokenTypes } from "../utils/constant/constant.js"

export const decoded_token = async ({authorization ="", tokenType = tokenTypes.access, next ={}}) =>{
    if (!authorization) {
        return next(new Error("Missing Authorization Header", { cause: 401 }));
    }
    const [bearer, token] = authorization.split(" ") || [];
    if(!bearer || !token)
    {
        return next(new Error("Invalid Token", {cause: 401}));
    }

    let ACCESS_SIGNATURE = undefined;
    let REFRESH_SIGNATURE = undefined;

    switch(bearer){
            case "Admin":  
            ACCESS_SIGNATURE =process.env.ADMIN_ACCESS_TOKEN;
            REFRESH_SIGNATURE =process.env.ADMIN_REFRESH_TOKEN;
            break;
            case "User": 
            ACCESS_SIGNATURE =process.env.USER_ACCESS_TOKEN;
            REFRESH_SIGNATURE =process.env.USER_REFRESH_TOKEN;
            break;
            // case "HR": 
            // ACCESS_SIGNATURE = process.env.HR_ACCESS_TOKEN;
            // REFRESH_SIGNATURE = process.env.HR_REFRESH_TOKEN;
            // break;
            // case "Owner": 
            // ACCESS_SIGNATURE = process.env.OWNER_ACCESS_TOKEN;
            // REFRESH_SIGNATURE = process.env.OWNER_REFRESH_TOKEN;
            //break;
            default: break;
        }

    const decoded = await verify({token, signature:  tokenType ? ACCESS_SIGNATURE : REFRESH_SIGNATURE});
    
    const user = await dbService.findOne({model: userModel, filter: {_id: decoded.id}});
    if(!user){
        return next(new Error ("User not found", {cause:404}));
    }

    if(user.changeCredentialTime?.getTime() >= decoded.iat *1000){
        return next(new Error ("Invalid token", {cause:400}));
    }
    return user;
};

export const authentication = () =>{
    return asyncHandler(async (req, res, next) => {
        const { authorization } = req.headers;
        req.user = await decoded_token({authorization, next});
        return next();
    });
}

export const allowto = (roles=[])=>{
    return asyncHandler (async (req, res, next) => { // middleware
        if(!roles.includes(req.user.role)){
            return next(new Error("Unauthorized", {cause: 403}));
        }
        return next();
    });
}

export default authentication;

