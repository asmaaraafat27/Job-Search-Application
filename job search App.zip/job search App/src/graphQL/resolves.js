// import userModel from "../DB/models/userModel.js"
// import companyModel from "../DB/models/companyModel.js"

// const resolvers = {
//   Query: {
//     getAllData: async () => {
//       const users = await userModel.find();
//       const companies = await companyModel.find();
//       return { users, companies };
//     },
//   },
//   Mutation: {
//     banUser: async (_, { userId, ban }) => {
//       const user = await userModel.findByIdAndUpdate(userId, { banned: ban }, { new: true });
//       if (!user) throw new Error("User not found");
//       return user;
//     },
//     banCompany: async (_, { companyId, ban }) => {
//       const company = await companyModel.findByIdAndUpdate(companyId, { banned: ban }, { new: true });
//       if (!company) throw new Error("Company not found");
//       return company;
//     },
//     approveCompany: async (_, { companyId }) => {
//       const company = await companyModel.findByIdAndUpdate(companyId, { approved: true }, { new: true });
//       if (!company) throw new Error("Company not found");
//       return company;
//     },
//   },
// };

// module.exports = resolvers;

