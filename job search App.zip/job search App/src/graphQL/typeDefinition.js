// import { gql } from "apollo-server";

// export const typeDefs = gql`
//   type User {
//     id: ID!
//     name: String!
//     email: String!
//     banned: Boolean!
//   }

//   type Company {
//     id: ID!
//     name: String!
//     approved: Boolean!
//     banned: Boolean!
//   }

//   type Query {
//     getAllData: AllDataResponse!
//   }

//   type AllDataResponse {
//     users: [User!]!
//     companies: [Company!]!
//   }

//   type Mutation {
//     banUser(userId: ID!, ban: Boolean!): User!
//     banCompany(companyId: ID!, ban: Boolean!): Company!
//     approveCompany(companyId: ID!): Company!
//   }
// `;
