import joi from "joi";
import { generalField } from "../../middlewares/validations.middleware.js";

export const addCompanySchema = joi.object({
    companyName: generalField.companyName.required(),
    description: generalField.description.required(),
    industry: generalField.industry.required(),
    address: joi.string().min(5).max(200).required(), 
    numberOfEmployees: joi.string()
        .valid("1-10", "11-20", "21-50", "51-100", "101-200", "201-500", "500+")
        .required(),
    companyEmail: generalField.companyEmail.required(),
    createdBy: generalField.id.required(), // Matches `Schema.Types.ObjectId`

    logo: joi.object({
        secure_url: joi.string().uri().allow(null),
        public_id: joi.string().allow(null),
    }).optional(),

    coverPic: joi.object({
        secure_url: joi.string().uri().allow(null),
        public_id: joi.string().allow(null),
    }).optional(),

    HRs: joi.array().items(generalField.id).optional(), // Array of HR ObjectIds

    bannedAt: joi.date().allow(null).optional(), // Matches your `bannedAt` field
    deletedAt: joi.date().allow(null).optional(), // Matches `deletedAt`

    legalAttachment: joi.object({
        secure_url: joi.string().uri().required(), // PDF/Image URL
        public_id: joi.string().required(),
    }).required(),

    approvedByAdmin: joi.boolean().default(false),
}).required();

export const updateCompanySchema = joi.object({
    companyId: generalField.id.required(), // Allow companyId from params
    companyName: generalField.companyName.optional(),
    description: generalField.description.optional(),
    industry: generalField.industry.optional(),
    address: joi.string().min(5).max(200).optional(), 
    numberOfEmployees: joi.string()
        .valid("1-10", "11-20", "21-50", "51-100", "101-200", "201-500", "500+")
        .optional(),
    companyEmail: generalField.companyEmail.optional(),

    logo: joi.object({
        secure_url: joi.string().uri().allow(null),
        public_id: joi.string().allow(null),
    }).optional(),

    coverPic: joi.object({
        secure_url: joi.string().uri().allow(null),
        public_id: joi.string().allow(null),
    }).optional(),

    HRs: joi.array().items(generalField.id).optional(),

    bannedAt: joi.date().allow(null).optional(),
    deletedAt: joi.date().allow(null).optional(),

    approvedByAdmin: joi.boolean().optional(),
}).required();

export const softDeleteCompanySchema = joi.object({
    companyId: generalField.id.required(), // Ensure companyId is a valid ObjectId
});

export const searchCompanySchema = joi.object({
    companyName: joi.string().min(2).max(50).required(),
});

export const uploadCompanyLogoSchema = joi.object({
    companyId: joi.string().required(), // Ensure companyId exists in params
}).unknown(true); // Allow req.file since it's handled by multer

export const deleteCompanyImageSchema = joi.object({
    companyId: joi.string().required(), // Validate companyId in params
});

