import { Router } from "express";
import * as companyService from "./company.service.js";;
import asyncHandler from "../../utils/asyncHandler.js"
import * as companyValidation from "./company.validation.js";
import  authentication  from "../../middlewares/Auth.middleware.js"
import { validation } from "../../middlewares/validations.middleware.js";
import { uploadCloud } from "../../utils/fileUploading/multerUpload.js";
//import jobRouter from "../jobs/jobs.controller.js"

const router = Router();

//router.use("/:companyId/jobs",jobRouter)

router.post(
    "/",
    authentication(),
    validation(companyValidation.addCompanySchema),
    asyncHandler(companyService.addCompany)
);

router.patch(
    "/:companyId",
    authentication(),
    validation(companyValidation.updateCompanySchema),
    asyncHandler(companyService.updateCompany)
);

router.delete(
    "/:companyId",
    authentication(),
    validation(companyValidation.softDeleteCompanySchema),
    asyncHandler(companyService.softDeleteCompany)
);

// router.get(
//     "/:companyId/getCompanyWithJobs",
//     validation(companyValidation.companyIdSchema),
//     asyncHandler(companyService.getCompanyWithJobs)
// );

router.get(
    "/search",
    authentication(),
    validation(companyValidation.searchCompanySchema),
    asyncHandler(companyService.searchCompanyByName)
);

router.post(
    "/:companyId/logo",
    authentication(),
    uploadCloud().single("logo"),
    validation(companyValidation.uploadCompanyLogoSchema),
    asyncHandler(companyService.uploadCompanyLogo)
);

router.post(
    "/:companyId/cover",
    authentication(),
    uploadCloud().single("cover"),
    validation(companyValidation.uploadCompanyLogoSchema),
    asyncHandler(companyService.uploadCompanyCoverPic)
);

router.delete(
    "/:companyId/logo",
    authentication(),
    validation(companyValidation.deleteCompanyImageSchema),
    asyncHandler(companyService.deleteCompanyLogo)
);

router.delete(
    "/:companyId/cover",
    authentication(),
    validation(companyValidation.deleteCompanyImageSchema),
    asyncHandler(companyService.deleteCompanyCoverPic)
);

export default router;