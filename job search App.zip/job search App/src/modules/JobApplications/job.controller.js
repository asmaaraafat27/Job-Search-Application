import { Router } from "express";
import *as jobService from "./job.service.js";
import asyncHandler  from "../../utils/asyncHandler.js"
import {authentication, allowto}  from "../../middlewares/Auth.middleware.js";

const router = Router();

router.post("/", authentication(), asyncHandler(jobService.addJob));

router.patch("/:jobId", authentication(),asyncHandler(jobService.updateJob));

router.delete("/:jobId", authentication(),asyncHandler(jobService.deleteJob));

router.get("/", authentication(), asyncHandler(jobService.getJobs));

router.get("/filter", authentication(), asyncHandler(jobService.filterJobs));

router.get("/:jobId/applications", authentication(), asyncHandler(jobService.getJobApplications));

router.post("/:jobId/apply", authentication(), allowto(["User"]), asyncHandler(jobService.applyToJob));

router.patch("/:jobId/applications/:applicationId", authentication(), asyncHandler(jobService.acceptRejectApplication));

export default router;