import { application } from "express";
import *as dbService from "../../DB/DB.Service.js";
import jobModel from "../../DB/models/JobOpportunityModel.js"
import applicationModel from "../../DB/models/applicationModel.js"

export const addJob =  async (req, res, next) => {
    const job = await dbService.create(
    {
        model: jobModel,
        data: { 
            ...req.body, 
            addedBy: req.user._id
        },  
    });
    res.status(201).json({ success: true, data: job });
};

export const updateJob = async (req, res, next) => {
    const job = await dbService.findById({
        model: jobModel, 
        id: req.params.jobId,
    });
    if (!job || job.addedBy.toString() !== req.user._id.toString()) {
        return new Error("Not authorized to update this job", {cause:403});
    }
    Object.assign(job, req.body, { updatedBy: req.user._id });
    await job.save();
    res.json({ success: true, data: job });
};


export const deleteJob =  async (req, res, next) => {

    const job = await dbService.findById({
        model: jobModel, 
        id: req.params.jobId,
    });
    if (!job || job.addedBy.toString() !== req.user._id.toString()) {
        return new Error("Not authorized to delete this job", {cause:403});
    }
    await job.deleteOne();
    res.json({ success: true, message: "Job deleted successfully" });
};


export const getJobs =  async (req, res, next ) => {

    const { companyName, skip = 0, limit = 10, sort = "-createdAt" } = req.query;
    let query = companyName ? { companyName: new RegExp(companyName, "i") } : {};
    const jobs = await dbService.find({
        model: jobModel,
        filter: query,
        skip: parseInt(skip),
        limit: parseInt(limit),
        sort
    });
    res.json({ success: true, data: jobs });
};

export const filterJobs =  async (req, res, next) => {
    const jobs = await dbService.find({
        model: jobModel,   
        filter: req.query,
        sort: { createdAt: -1 }  
    });
    res.json({ success: true, data: jobs });
};

export const getJobApplications=  async (req, res, next) => {
    
    const { skip = 0, limit = 10 } = req.query;
    const applications = await dbService.find({
        model: applicationModel,   
        filter: { jobId: req.params.jobId },
        populate: ["userId"],
        skip: parseInt(skip),
        limit: parseInt(limit),
    });
    res.json({ success: true, data: applications });
};

export const applyToJob = async (req, res, next) => {
    const job = await dbService.findById({
        model: jobModel,
        id: req.params.jobId,
        populate: ["companyId"]
    });
    if (!job) {
        return new Error("Job not found", {cause:404});
    }

    if (!req.user.email || !req.user.name) {
        return new Error("User information is incomplete", {cause:400});
    }

    const application = await dbService.create({
        model: applicationModel,
        data: {
            jobId: req.params.jobId,
            companyId: job.companyId,  
            applicantName: req.user.name,  
            email: req.user.email,  
            position: job.jobTitle,
            userId: req.user._id
        }
    });

    res.status(201).json({ success: true, data: application });
};

export const acceptRejectApplication = async (req, res) => {
    const application = await findById({
        model: applicationModel,
        id: req.params.applicationId
    });
    
    if (!application) {
        return new Error("Application not found", {cause:404});
    }
    application.status = req.body.status;
    await application.save();
    res.json({ success: true, message: `Application ${req.body.status} successfully `});
};
