import XLSX from "xlsx";
import fs from "fs";
import path from "path";
import appModel from "../../DB/models/applicationModel.js";

export const exportApplications =  async (req, res, next) => {
        const { companyId, date } = req.query;
        if (!companyId || !date) {
            return next(new Error("companyId and date are required", {cause: 400}));
        }

        const targetDate = new Date(date);
        targetDate.setUTCHours(0, 0, 0, 0);

        const nextDay = new Date(targetDate);
        nextDay.setUTCDate(nextDay.getUTCDate() + 1);

        const applications = await appModel.find({
            companyId,
            appliedDate: { $gte: targetDate, $lt: nextDay },
        });

        if (applications.length === 0) {
            return next(new Error("No applications found for this company on this date", {cause: 400}));
        }

        const data = applications.map((app) => ({
            Name: app.applicantName,
            Email: app.email,
            Position: app.position,
            AppliedDate: app.appliedDate.toISOString(),
        }));

        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Applications");

        const filePath = path.join(process.cwd(), `applications_${companyId}_${date}.xlsx`);
        XLSX.writeFile(wb, filePath);

        res.download(filePath, (err) => {
            if (err) {
                console.error("Error sending file:", err);
                res.status(500).json({ error: "Error generating file" });
            }
            fs.unlinkSync(filePath); // Delete file after sending
        });
};

