import { Router } from "express";
import asyncHandler  from "../../utils/asyncHandler.js";
import { exportApplications } from "./file.service.js";

const router = Router();

router.get("/export-applications", asyncHandler(exportApplications));

export default router;