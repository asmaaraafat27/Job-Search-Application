import *as dbService from "../../DB/DB.Service.js";
import userModel, { defaultImage, public_idImage } from "../../DB/models/userModel.js";
import {hash , compareHash} from "../../utils/hashing/hash.js";
import {encrypt} from "../../utils/ecryption/encryption.js"
import cloudinary from "../../utils/fileUploading/cloudinaryConfig.js";

export const getProfile = async (req, res, next) => {

    if (!req.user || !req.user._id) {
        return res.status(400).json({ success: false, message: "Invalid user ID" });
    }

    const user = await dbService.findById({
    model: userModel, 
    id: req.user._id,
    select:"-password",
    });
    return res.status(200).json({success: true, message: "Profile gets successfully", user: req.user});
};

export const updatePassword = async (req, res, next) => {
    const {oldPassword, password} = req.body;
    if(!compareHash({plainText: oldPassword, hash: req.user.password}))
        return next(new Error("Invalid Password", {cause: 400}));

    const user = await dbService.updateOne({model: userModel, 
        filter: {_id: req.user._id}, data: {password: hash({plainText: password}), changeCredentialTime: Date.now()},
    });
    return res.status(200).json({success: true, messsage: "Password updated successfully"});
};

export const updateProfile = async (req, res, next) => {
    const {firstName, lastName, gender,  mobileNumber, DOB} = req.body;

    let encryptedPhone;
    if (mobileNumber) {
        encryptedPhone = encrypt({ plaintext: mobileNumber, signature: process.env.ENCRYPTION_SECRET });
    }
    // Prepare the updated data object
    const updatedData = { firstName, lastName, gender, DOB };
    if (encryptedPhone) {
        updatedData.mobileNumber = encryptedPhone;
    }

    const user = await dbService.findOneAndUpdate({
        model: userModel,
        filter: {_id: req.user._id },
        data: updatedData,
        options: { new: true }, //runValidators: true},
    });
    return res.status(200).json({success: true, message: "Profile updated successfully",results: {user}});
};

export const getOtherUserProfile = async (req, res, next) => {
    if (!req.params.userId) {
        return next(new Error("Invalid user ID", {cause: 400}));

    }
    const user = await dbService.findById({
        model: userModel,
        id: req.params.userId,
        select: "firstName lastName mobileNumber profilePic coverPic",
    });
    if (!user) {
        return next(new Error("User not found!!", {cause: 400}));
    }
    return res.status(200).json({ success: true, message: "Users gets successfully", results: { user }});
};

export const uploadProfilePicture =  async (req, res, next) => {

    const user = await dbService.findById({
        model: userModel,
        id: { _id: req.user._id },
    })

    const {secure_url, public_id} = await cloudinary.uploader.upload(req.file.path, {
        folder: `Users/${user._id}/profilePicture`,
    });

    user.profilePic = {secure_url, public_id};
    await user.save();

    return res.status(200).json({ success: true, message: "Profile picture uploaded successfully" , data: { user }});
};

export const deleteProfilePicture = async (req, res, next) => {

    const user = await dbService.findById({
        model: userModel,
        id: { _id: req.user._id },
    });

    const results = await cloudinary.uploader.destroy(
        user.profilePic.public_id
    );

    if(results.result === "ok"){
        user.profilePic = {
            secure_url: defaultImage,
            public_id: public_idImage,
        };
    };

    await user.save();

    return res.status(200).json({ success: true, message: "Profile picture deleted successfully" , data: { user }});

};

export const uploadCoverPicture =  async (req, res, next) => {


    const {secure_url, public_id} = await cloudinary.uploader.upload(req.file.path, {
        folder: `Users/${req.user._id}/coverPicture`,
    });
    const user = await dbService.findByIdAndUpdate({
        model: userModel,
        id: req.user._id,
        data: { coverPic: { public_id, secure_url } },
        options: { new: true }
    });
    
    user.coverPic.push = {secure_url, public_id};
    await user.save();

    return res.status(200).json({ success: true, message: "Cover uploaded successfully" , data: { user }});

};

export const deleteCoverPicture = async (req, res, next) => {

    const user = await dbService.findById({
        model: userModel,
        id: { _id: req.user._id },
    });

    const results = await cloudinary.uploader.destroy(
        user.coverPic.public_id
    );

    if(results.result === "ok"){
        user.coverPic = {
            secure_url: defaultImage,
            public_id: public_idImage,
        };
    };

    await user.save();

    return res.status(200).json({ success: true, message: "Cover deleted successfully" , data: { user }});
};

export const softDeleteAccount = async (req, res, next) => {
    const { email } = req.body;
    // Find the user by email
    const user = await dbService.findOne({ model: userModel, filter: { email } });
    if (!user) {
        return next(new Error("user not found!"), {cause: 404});
    }
    // Soft delete by setting isDeleted flag
    await dbService.updateOne({ model: userModel, filter: { email }, data: { deletedAt: new Date() } });

    return res.status(200).json({ success: true, message: "Account soft deleted successfully" });
};
