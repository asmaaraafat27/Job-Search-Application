import joi from "joi";
import { generalField } from "../../middlewares/validations.middleware.js"

export const updateProfileSchema = joi.object({
    firstName: generalField.firstName,
    lastName: generalField.lastName,
    mobileNumber: generalField.mobileNumber,
    gender: generalField.gender,
    DOB: generalField.DOB,
}).required();

export const shareProfileSchema = joi.object({
    profileId: generalField.id.required(),
}).required();

export const updatePasswordSchema = joi.object({
    oldPassword: generalField.password.required(),
    password: generalField.password.not(joi.ref("oldPassword")).required(),
    isConfirmed: generalField.isConfirmed.required(),
}).required();

export const uploadProfilePicSchema = joi.object({
    file: joi.object(generalField.fileObject),
}).required();

export const uploadCoverPicSchema = joi.object({
    file: joi.object(generalField.fileObject),
}).required();

export const deleteProfilePicSchema = joi.object({
    userId: generalField.id.required(),
}).required();

export const deleteCoverPicSchema = joi.object({
    userId: generalField.id.required(), 
}).required();

// ✅ Reusable Middleware for Validation
export const validateRequest = (schema) => (req, res, next) => {
    const { error } = schema.validate(req.body, { abortEarly: false });

    if (error) {
        return res.status(400).json({ 
            success: false, 
            message: "Validation failed!",
            errors: error.details.map(err => err.message),
        });
    }

    next(); 
};

export default validateRequest;
