import { Router } from "express";
import * as userService from "./user.service.js";
import { allowto, authentication } from "../../middlewares/Auth.middleware.js";
import asyncHandler  from "../../utils/asyncHandler.js";
import { uploadCloud } from "../../utils/fileUploading/multerUpload.js";
import validateRequest, { deleteCoverPicSchema, deleteProfilePicSchema, shareProfileSchema, updatePasswordSchema, updateProfileSchema, uploadCoverPicSchema, uploadProfilePicSchema }  from "../User/user.validation.js"

const router = Router();

router.get("/getProfile",authentication(), asyncHandler(userService.getProfile)); 
router.patch("/updatePassword", authentication(),validateRequest(updatePasswordSchema), allowto(["User"]), asyncHandler(userService.updatePassword)); 
router.patch("/updateProfile", authentication(), validateRequest(updateProfileSchema), allowto(["User"]), asyncHandler(userService.updateProfile)); 
router.get("/profile/:userId", authentication(), validateRequest(shareProfileSchema), allowto(["User"]), asyncHandler(userService.getOtherUserProfile));

router.post("/profilePicture", authentication(),validateRequest(uploadProfilePicSchema), allowto(["User"]), uploadCloud().single("image"), asyncHandler(userService.uploadProfilePicture));
router.post("/coverPicture", authentication(), validateRequest(uploadCoverPicSchema), allowto(["User"]), uploadCloud().single("cover"), asyncHandler(userService.uploadCoverPicture));
router.delete("/deleteProfilePic", authentication(), validateRequest(deleteProfilePicSchema), allowto(["User"]), uploadCloud().single("image"), asyncHandler(userService.deleteProfilePicture));
router.delete("/deleteCoverPic", authentication(),validateRequest(deleteCoverPicSchema), allowto(["User"]), uploadCloud().single("cover"), asyncHandler(userService.deleteCoverPicture));

router.patch("/softDeleteAcc", authentication(), allowto(["User"]), asyncHandler(userService.softDeleteAccount));

export default router;