import userModel from "../../DB/models/userModel.js";
import {roleTypes, providersType, tokenTypes} from "../../utils/constant/constant.js"
import { compareHash, hash } from "../../utils/hashing/hash.js";
import { emailEmitter } from "../../utils/email/email.Event.js";
import { sign } from "../../utils/token/token.js";
import { encrypt } from "../../utils/ecryption/encryption.js";
import { OAuth2Client } from "google-auth-library";
import *as dbService from "../../DB/DB.Service.js";
import { decoded_token } from "../../middlewares/Auth.middleware.js";

export const signUp = async (req, res, next)=>{
    const { firstName, lastName, email, password, mobileNumber, DOB, gender } = req.body;

    const checkUser = await dbService.findOne({model: userModel, filter: {email}});
    if (checkUser) {
        return next(new Error("user already exists"), {cause: 409});
    }

    const hashPassword = hash({plainText: password});

    //encryption
    const encryptPhone = encrypt({plaintext: mobileNumber, signature: process.env.ENCRYPTION_SECRET});

    const user = await dbService.create({model: userModel,
        data: {
            firstName,
            lastName,
            email,
            password: hashPassword,
            mobileNumber: encryptPhone, 
            DOB, 
            gender,
        },
    });
    emailEmitter.emit("sendEmail", email, firstName, lastName); 

    return res.status(201).json({success:true, message: "user signed up successfully!!", user});
};

export const login = async (req, res, next) => {
    const { email, password } = req.body;
    const user = await dbService.findOne({model: userModel, filter: {email}});
    if (!user) {
        return next(new Error("user not found!"), {cause: 404});
    }
    if (!user.isConfirmed) {
        return next(new Error("please confirm your Email!!!"), {cause: 401});
    }
    
    if(!(compareHash({plainText: password, hash: user.password}))){
        return next(new Error("invalid password"), {cause: 400});
    }

    const access_token = sign({
        payload: {id : user._id}, 
        signature: user.role === roleTypes.user? process.env.USER_ACCESS_TOKEN : process.env.ADMIN_ACCESS_TOKEN,
        options: {expiresIn: process.env.ACCESS_TOKEN_EXPIRES}
    });

    const refresh_token = sign({
        payload: {id : user._id}, 
        signature: user.role === roleTypes.user? process.env.USER_REFRESH_TOKEN : process.env.ADMIN_REFRESH_TOKEN,
        options: {expiresIn: process.env.REFRESH_TOKEN_EXPIRES}
    });
    return res.status(200).json({success: true, message:"User logged in successfully!", tokens: {access_token, refresh_token}});
};

export const activateAccount = async (req, res, next) => {
    const { code, email } = req.body;
    
    const user = await dbService.findOne({model: userModel, filter: {email}});
    if (!user) {
        return next(new Error("User not found!"), {cause: 400});
    }
    if(user.isConfirmed === true){
        return next(new Error("Email already verified"), {cause: 409});
    }
    if(!(compareHash({plainText: code, hash: user.OTP}))){
        return next(new Error("Invalid code"), {cause: 400});
    }
    await dbService.updateOne({model: userModel, filter: {email}, data: {isConfirmed: true, $unset: { OTP:"" }}})
    return res.status(200).json({success: true, message:"Email verified Successfully!"});
};

export const refresh_token = async (req, res, next) => {
    const { authorization } = req.headers;
    if (!authorization) {
        return res.status(401).json({ success: false, message: "Authorization header is missing" });
    }
    const user = await decoded_token({authorization, tokenType: tokenTypes.refresh, next});

    const access_token = sign({
        payload: {id : user._id}, 
        signature: user.role === roleTypes.user? process.env.USER_ACCESS_TOKEN : process.env.ADMIN_ACCESS_TOKEN,
        options: {expiresIn: process.env.ACCESS_TOKEN_EXPIRES}
    });

    const refresh_token = sign({
        payload: {id : user._id}, 
        signature: user.role === roleTypes.user? process.env.USER_REFRESH_TOKEN : process.env.ADMIN_REFRESH_TOKEN,
        options: {expiresIn: process.env.REFRESH_TOKEN_EXPIRES}
    });
    return res.status(200).json({success: true, message:"User logged in successfully!", tokens: {access_token, refresh_token}});
};

export const loginWithGmail = async(req, res, next) => {
    const { idToken } = req.body;
    const client = new OAuth2Client();
    async function verify(){
        const ticket = await client.verifyIdToken({
            idToken,
            audience: process.env.CLIENT_ID,
        });
        const payload = ticket.getPayload();
        return payload;
    };
    const {given_name, family_name, email, email_verified } = await verify();
    if(!(email_verified)){
        return next(new Error("Email not verified", {cause: 401}));
    };

    let user = await dbService.findOne({ email });
    if(user?.provider === providersType.system){
        return next(new Error("User already exists", {cause: 409}));
    };
    if (!user) {
        user = await dbService.create({ 
            model: userModel,
            data: {
            firstName: given_name, lastName: family_name,
            email, 
            picture: profilePic, 
            isConfirmed: email_verified,
            provider: providersType.google,
            }
        });
    };
    const access_token = sign({
        payload: {id : user._id}, 
        signature: user.role === roleTypes.user? process.env.USER_ACCESS_TOKEN : process.env.ADMIN_ACCESS_TOKEN,
        options: {expiresIn: process.env.ACCESS_TOKEN_EXPIRES}
    });

    const refresh_token = sign({
        payload: {id : user._id}, 
        signature: user.role === roleTypes.user? process.env.USER_REFRESH_TOKEN : process.env.ADMIN_REFRESH_TOKEN,
        options: {expiresIn: process.env.REFRESH_TOKEN_EXPIRES}
    });
    return res.status(200).json({success: true, tokens: {access_token, refresh_token}});
};

export const forgetPassword = async(req, res, next) => {
    const { email } = req.body;
    const user = await dbService.findOne({model: userModel, filter: {email}});
    if (!user) {
        return next(new Error("user not found!"), {cause: 404});
    }
    emailEmitter.emit("forgetPassword", email, user.firstName, user.lastName);
    return res.status(200).json({success: true, message: "Email sent successfully"});
};

export const resetPassword = async(req, res, next) => {
    const { email, password, code } = req.body; 
    const user = await dbService.findOne({model: userModel, filter: {email}});
    if (!user) {
        return next(new Error("user not found!"), {cause: 404});
    }

    if(!(compareHash({plainText: code, hash: user.forgetPasswordOTP}))){
        return next(new Error("Invalid code"), {cause: 404});
    }
    const hashPassword = hash({plainText: password});
    await dbService.updateOne({model: userModel, filter: {email}, data: {password: hashPassword, $unset:{forgetPasswordOTP:""}}});

    return res.status(200).json({success: true, message:"Password reseted successfully" });
};
