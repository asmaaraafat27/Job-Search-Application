import { Router } from "express";
import * as authService from "./auth.service.js";
import asyncHandler from "../../utils/asyncHandler.js"
import validateRequest, { confirmEmailSchema, forgetPasswordSchema, loginSchema, registerSchema, resetPasswordSchema } from "../Auth/auth.validation.js"

const router = Router();

router.post("/signUp", validateRequest(registerSchema), asyncHandler(authService.signUp));
router.post("/login", validateRequest(loginSchema), asyncHandler(authService.login));
router.patch("/activateAcc", validateRequest(confirmEmailSchema), asyncHandler(authService.activateAccount));
router.patch("/forgetPassword", validateRequest(forgetPasswordSchema), asyncHandler(authService.forgetPassword));
router.patch("/resetPassword", validateRequest(resetPasswordSchema), asyncHandler(authService.resetPassword));
router.get("/refresh_token", asyncHandler(authService.refresh_token));
router.post("/loginWithGmail", asyncHandler(authService.loginWithGmail));

export default router;