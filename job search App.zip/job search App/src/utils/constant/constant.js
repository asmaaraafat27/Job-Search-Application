export const genderType = {
    male: "male",
    female: "female",
}
export const roleTypes = {
    user: "User",
    admin: "Admin",
}
export const providersType = {
    google: "google",
    system: "system",
}

export const tokenTypes = {
    access: "access", 
    refresh: "refresh",
}

export const subject = {
    verifyEmail: "Verify Email",
    resetPassword: "Reset Password",
};

export const otpTypes ={
    confirmEmail: "Confirm your Email",
    forgetPassword: "Forget Password",
}