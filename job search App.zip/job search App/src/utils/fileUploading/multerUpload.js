import multer, { diskStorage } from "multer";
// import { nanoid } from "nanoid";
import path from "path";
// import fs from "fs";



//Disk Storage
export const uploadCloud = () => {
    const storage = diskStorage ({});

    // const fileFilter = (req, file, cb) => {
    //     if (!fileType.includes(file.mimetype)) {
    //         return cb(new Error("Invalid file type"), false);
    //     }
    //     return cb(null, true);
    // };

    const multerUpload = multer({ storage});
    return multerUpload;
};