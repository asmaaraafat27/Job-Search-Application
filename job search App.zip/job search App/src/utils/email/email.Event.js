import { EventEmitter } from "events";
import { sendEmail } from "./sendEmail.js";
import { customAlphabet } from "nanoid";
import { hash } from "../hashing/hash.js"
import userModel  from "../../DB/models/userModel.js";
import { template } from "./generateHTML.js";
import { sign } from "../token/token.js";
import *as dbService from "../../DB/DB.Service.js";
import { subject} from "../constant/constant.js"

export const emailEmitter = new EventEmitter();

emailEmitter.on("sendEmail", async(email, firstName, lastName)=>{

    const token = sign({payload: { email }, signature: process.env.TOKEN_SECRET_EMAIL});
    const otp = customAlphabet("123456789", 5)();
    const hashOTP = hash({plainText: otp});

    await dbService.updateOne({model: userModel, filter: {email}, data:{OTP: hashOTP}});
    
    await sendEmail({
        to: email,
        subject: subject.verifyEmail,
        html: template(otp, firstName, lastName, subject.verifyEmail),
    });
    if (!sendEmail) {
        throw new Error("Failed to send email");
    }
});

emailEmitter.on("forgetPassword", async(email, firstName, lastName)=>{

    const token = sign({payload: { email }, signature: process.env.TOKEN_SECRET_EMAIL});
    const otp = customAlphabet("123456789", 5)();
    const hashOTP = hash({plainText: otp});

    await dbService.updateOne({model: userModel, filter: {email}, data:{ forgetPasswordOTP: hashOTP }});
    
    await sendEmail({
        to: email,
        subject: subject.resetPassword,
        html: template(otp, firstName, lastName, subject.resetPassword),
    });
    if (!sendEmail) {
        throw new Error("Failed to send email");
    }
});

