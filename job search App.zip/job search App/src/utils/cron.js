import cron from "node-cron";
import userModel from "../DB/models/userModel.js"

const deleteExpiredOTPs = () => {
    cron.schedule("0 */6 * * *", async () => { 
        try {
            console.log("Running CRON Job: Deleting expired OTPs...");
            const result = await userModel.updateMany(
                {},
                { $pull: { OTP: { expiresIn: { $lte: new Date() } } } }
            );
            console.log("Expired OTPs deleted successfully.");
        } catch (error) {
            console.error("Error in CRON Job:", error);
        }
    });
};

export default deleteExpiredOTPs;