import connectDB from "./DB/connection.js";
import authRouter from "./modules/Auth/auth.controller.js";
import userRouter from "./modules/User/user.controller.js";
import companyRouter from "./modules/Company/company.controller.js"
import AppRouter from "./modules/generateExcelFile/file.controller.js"
import jobRouter from "./modules/JobApplications/job.controller.js"
import cors from "cors";
import rateLimit from "express-rate-limit";
import helmet from "helmet";

const bootstrap = async(app, express)=>{

    await connectDB();

    //middlewares
    app.use(express.json());
    app.use("/uploads", express.static("uploads"));
    
    const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Max 100 requests per IP
    message: "Too many requests from this IP, please try again later."
    });
    app.use(limiter);
    app.use(helmet());
    app.use(cors({
        origin: ["http://localhost:3000", "https://yourfrontend.com"], // Adjust to your frontend URL
        methods: "GET,POST,PUT,DELETE",
        allowedHeaders: "Content-Type,Authorization"
    }));

    //routers
    app.use("/auth", authRouter); //Auth
    app.use("/user", userRouter); //User
    app.use("/company", companyRouter) //Company
    app.use("/job", jobRouter) // Job
    app.use("/api", AppRouter) //Export Applications Router
    
    app.all("*", (req,res, next)=>{
        return next(new Error("not found handler!!!"), {cause: 404})
    });
    //global middleware
    app.use((error, req, res, next)=>{
        const status = error.cause || 500;
        return res.status(status).json({success: false, message: error.message, stack: error.stack});
    });
}

export default bootstrap;