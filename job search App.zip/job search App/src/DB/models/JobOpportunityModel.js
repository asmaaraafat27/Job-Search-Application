import mongoose, { Schema } from "mongoose";
import applicationModel from "./applicationModel.js";

const jobSchema = new Schema({
    jobTitle: { 
        type: String, 
        required: true, 
        trim: true 
    },
    jobLocation: { 
        type: String, 
        enum: ["onsite", "remotely", "hybrid"], 
        required: true 
    },
    workingTime: { 
        type: String, 
        enum: ["part-time", "full-time"], 
        required: true 
    },
    seniorityLevel: { 
        type: String, 
        enum: ["fresh", "Junior", "Mid-Level", "Senior", "Team-Lead", "CTO"], 
        required: true 
    },
    jobDescription: { 
        type: String, 
        required: true, 
        trim: true 
    },
    technicalSkills: { 
        type: [String], 
        required: true 
    },
    softSkills: { 
        type: [String], 
        required: true 
    },
    addedBy: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: "userModel", 
        required: true 
    },
    updatedBy: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: "userModel", 
        default: null 
    },
    closed: { 
        type: Boolean, 
        default: false 
    },
    companyId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: "companyModel", 
        required: true 
    }
}, 
{ timestamps: true });

// Hook: Delete Applications when a Job is Deleted
jobSchema.pre("deleteOne", { document: true, query: false }, async function (next) {
    await applicationModel.deleteMany({ jobId: this._id });
    next();
});

const jobModel = mongoose.model("job", jobSchema);
export default jobModel;
