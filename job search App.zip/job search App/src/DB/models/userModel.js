import mongoose, {Schema} from "mongoose";
import { hash } from "../../utils/hashing/hash.js";
import { encrypt, decrypt} from "../../utils/ecryption/encryption.js"
import {genderType, roleTypes, providersType} from "../../utils/constant/constant.js"

export const defaultImage = "https://res.cloudinary.com/dkpqpmh77/image/upload/v1741469086/defaultProfilePicture_nivnfz.jpg";
export const public_idImage = "defaultProfilePicture_nivnfz";

const userSchema = new Schema({
    firstName: { type: String, required: true, trim: true },
    lastName: { type: String, required: true, trim: true },
    email: { 
        type: String,
        required: [true, "Email is required" ],
        unique: [true, "Email must be unique"],
        lowercase: true,
        trim: true,
    },
    password: { type: String },
    provider: { type: String, enum: Object.values(providersType), default: providersType.system},
    gender: { type: String, enum: {values: Object.values(genderType), 
        message: "Gender must be either 'male' or 'female'"},
    },
    DOB: { 
        type: Date, 
        validate: {
            validator: function (value) {
                const ageDiff = new Date().getFullYear() - value.getFullYear();
                return ageDiff >= 18;
            },
            message: "User must be at least 18 years old",
        },
    },
    mobileNumber: { type: String,},
    role: { 
        type: String,
        enum: Object.values(roleTypes), // object in auth Middleware
        default: roleTypes.user,
    },
    isConfirmed:{
        type: Boolean,
        default: false,
    },
    deletedAt: { type: Date, default: null },
    bannedAt: { type: Date, default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    changeCredentialTime: { type: Date, default: null },
    profilePic: { 
        secure_url: { type: String, default: defaultImage },
        public_id: { type: String, default: public_idImage },
    },
    coverPic: { 
        secure_url: { type: String, default: defaultImage},
        public_id: { type: String, default: public_idImage },
    },
    OTP: {type: String},
    forgetPasswordOTP: {
        hashedCode: String,
        type: String,
        expiresIn: Number, 
    },
},
    { timestamps: true }
);

userSchema.virtual("username").get(function () {
    return `${this.firstName} ${this.lastName}`;
});


//hook
userSchema.pre("save", function (next) {
    if (this.isModified("password")) {
        this.password = hash({ plainText: this.password });
    }
    if (this.isModified("mobileNumber")) {
        this.mobileNumber = encrypt({ plainText: this.mobileNumber, signature: process.env.ENCRYPTION_SECRET });
    }
    next();
});

// Decrypt mobileNumber only when retrieving user data
userSchema.post("init", function (doc) {
    if (doc.mobileNumber) {
        doc.mobileNumber = decrypt({ encrypted: doc.mobileNumber, signature: process.env.ENCRYPTION_SECRET });
    }
});

const userModel = mongoose.model("usermodel", userSchema);
export default userModel;