import mongoose from "mongoose";
import companyModel from "./companyModel.js";
const { Schema, model } = mongoose;

const applicationSchema = new Schema({
    companyId: { type: Schema.Types.ObjectId, ref: "companyModel", required: true },  
    applicantName: { type: String, required: true },
    email: { type: String, required: true },
    position: { type: String, required: true },
    appliedDate: { type: Date, default: Date.now },
}, { timestamps: true });

const applicationModel = model("applications", applicationSchema);
export default applicationModel;
