import mongoose from "mongoose";
import jobModel from "./JobOpportunityModel.js";
import applicationModel from "./applicationModel.js";
const { Schema, model } = mongoose;

const companySchema = new Schema(
    {
        companyName: { type: String, required: true, unique: true, trim: true },
        description: { type: String, required: true, trim: true },
        industry: { type: String, required: true, trim: true },
        address: { type: String, required: true, trim: true },
        numberOfEmployees: { 
            type: String, 
            required: true, 
            enum: ["1-10", "11-20", "21-50", "51-100", "101-200", "201-500", "500+"],
        },
        companyEmail: { type: String, required: true, unique: true, lowercase: true, trim: true },
        createdBy: { type: Schema.Types.ObjectId, ref: "userModel", required: true },

        logo: { 
            secure_url: { type: String, default: null },
            public_id: { type: String, default: null },
        },

        coverPic: { 
            secure_url: { type: String, default: null },
            public_id: { type: String, default: null },
        },

        HRs: [{ type: Schema.Types.ObjectId, ref: "usermodel" }], // Array of HR user IDs

        bannedAt: { type: Date, default: null },
        deletedAt: { type: Date, default: null },

        legalAttachment: {
            secure_url: { type: String, required: true }, // PDF or Image
            public_id: { type: String, required: true },
        },

        approvedByAdmin: { type: Boolean, default: false },
    }, 
    { timestamps: true }
);

// Virtual for full company info
companySchema.virtual("fullCompanyName").get(function () {
    return `${this.companyName} - ${this.industry}`;
});

// Hook: Delete Jobs and Applications when a Company is Deleted
companySchema.pre("deleteOne", { document: true, query: false }, async function (next) {
    await jobModel.deleteMany({ companyId: this._id }); // Delete jobs
    await applicationModel.deleteMany({ companyId: this._id }); // Delete related applications
    next();
});

const companyModel = model("companymodel", companySchema);
export default companyModel;
