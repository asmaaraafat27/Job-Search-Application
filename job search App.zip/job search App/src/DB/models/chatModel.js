// import mongoose, { Schema } from "mongoose";
// import { roleTypes } from "../../middlewares/Auth.middleware.js"; 

// const chatSchema = new Schema({
//     senderId: { 
//         type: mongoose.Schema.Types.ObjectId, 
//         ref: "usermodel", 
//         required: true,
//         validate: {
//             validator: async function (senderId) {
//                 const user = await mongoose.model("usermodel").findById(senderId);
//                 return user && (user.role === roleTypes.HR || user.role === roleTypes.CompanyOwner);
//             },
//             message: "Sender must be HR or Company Owner"
//         }
//     },
//     receiverId: { 
//         type: mongoose.Schema.Types.ObjectId, 
//         ref: "usermodel", 
//         required: true 
//     },
//     messages: [{
//         message: { type: String, required: true, trim: true },
//         senderId: { type: mongoose.Schema.Types.ObjectId, ref: "usermodel", required: true },
//         timestamp: { type: Date, default: Date.now }
//     }]
// }, 
// { timestamps: true });

// const chatModel = mongoose.model("chat", chatSchema);
// export default chatModel;
